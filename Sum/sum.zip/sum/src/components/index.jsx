import men from '../mg/menu.png'

export const navItems = [
    {label:"Features", href: "#"},
    {label:"Reviews", href: "#"},
    {label:"Our professionals", href: "#"},
    {label:"Contact Us", href: "#"},
];
export const features =[
    {
        icon: "X",
        text: "Drag and drop Interface",
        description: "Easily designs and arange your VR enviroment with a user friendly drag-and-drop interface,",
    },
    {
        icon: "X",
        text: "Drag and drop Interface",
        description: "Easily designs and arange your VR enviroment with a user friendly drag-and-drop interface,",
    },
    {
        icon: "X",
        text: "Drag and drop Interface",
        description: "Easily designs and arange your VR enviroment with a user friendly drag-and-drop interface,",
    },
    {
        icon: "X",
        text: "Drag and drop Interface",
        description: "Easily designs and arange your VR enviroment with a user friendly drag-and-drop interface,",
    },
    {
        icon: "X",
        text: "Drag and drop Interface",
        description: "Easily designs and arange your VR enviroment with a user friendly drag-and-drop interface,",
    },
    {
        icon: "X",
        text: "Drag and drop Interface",
        description: "Easily designs and arange your VR enviroment with a user friendly drag-and-drop interface,",
    },
];
export const testim = [
    {
        user: "John Doe",
        company: "Apple Inc",
        image: "X",
        text: "I am extremely sat]sfed wth the servces provded.The team was responsve professonal and well mannered thans for all you do",
    },
    {
        user: "John Doe",
        company: "Apple Inc",
        image: "X",
        text: "I am extremely sat]sfed wth the servces provded.The team was responsve professonal and well mannered thans for all you do",
    },
    {
        user: "John Doe",
        company: "Apple Inc",
        image: "X",
        text: "I am extremely sat]sfed wth the servces provded.The team was responsve professonal and well mannered thans for all you do",
    },
    {
        user: "John Doe",
        company: "Apple Inc",
        image: "X",
        text: "I am extremely sat]sfed wth the servces provded.The team was responsve professonal and well mannered thans for all you do",
    },
    {
        user: "John Doe",
        company: "Apple Inc",
        image: "X",
        text: "I am extremely sat]sfed wth the servces provded.The team was responsve professonal and well mannered thans for all you do",
    },
    {
        user: "John Doe",
        company: "Apple Inc",
        image: "X",
        text: "I am extremely sat]sfed wth the servces provded.The team was responsve professonal and well mannered thans for all you do",
    },
];
 export const X =()=>{
    return(
        <>
        <h1>X</h1>
        </>
    )
}

const Menu =()=>{
    return(
        <>
        <img src={men} className='h-10'/>
        </>
    )
}
export default Menu;